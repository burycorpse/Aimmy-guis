﻿using AimmyWPF.Class;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Animation;
using Color = System.Windows.Media.Color;
using ColorConverter = System.Windows.Media.ColorConverter;

namespace Aimmy2.UILibrary
{
    /// <summary>
    /// Interaction logic for AToggle.xaml
    /// </summary>
    public partial class AToggle : System.Windows.Controls.UserControl
    {
        private static Color EnableColor = (Color)ColorConverter.ConvertFromString("#7469A0");
        private static Color DisableColor = (Color)ColorConverter.ConvertFromString("#151519");
        private static Color TextEnableColor = (Color)ColorConverter.ConvertFromString("#B7B4BB");
        private static Color TextDisableColor = (Color)ColorConverter.ConvertFromString("#716D77");
        private static TimeSpan AnimationDuration = TimeSpan.FromMilliseconds(200);

        public AToggle(string Text)
        {
            InitializeComponent();
            ToggleTitle.Content = Text;
        }

        public void SetColorAnimation(Color fromColor, Color toColor, TimeSpan duration, DependencyProperty property, Brush brush)
        {
            ColorAnimation animation = new ColorAnimation(fromColor, toColor, duration);
            brush.BeginAnimation(SolidColorBrush.ColorProperty, animation);
        }

        public void EnableSwitch()
        {
            Color currentColor = (Color)SwitchMoving.Background.GetValue(SolidColorBrush.ColorProperty);
            Color currentTextColor = ((SolidColorBrush)ToggleTitle.Foreground).Color;
            
            SetColorAnimation(currentColor, EnableColor, AnimationDuration, SolidColorBrush.ColorProperty, SwitchMoving.Background);
            SetColorAnimation(currentTextColor, TextEnableColor, AnimationDuration, SolidColorBrush.ColorProperty, ToggleTitle.Foreground);
        }

        public void DisableSwitch()
        {
            Color currentColor = (Color)SwitchMoving.Background.GetValue(SolidColorBrush.ColorProperty);
            Color currentTextColor = ((SolidColorBrush)ToggleTitle.Foreground).Color;
            
            SetColorAnimation(currentColor, DisableColor, AnimationDuration, SolidColorBrush.ColorProperty, SwitchMoving.Background);
            SetColorAnimation(currentTextColor, TextDisableColor, AnimationDuration, SolidColorBrush.ColorProperty, ToggleTitle.Foreground);
        }
    }
}