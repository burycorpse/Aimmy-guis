﻿using Other;
using System.Windows;
using System.Windows.Input;
using System.Windows.Controls;

namespace Aimmy2.UILibrary
{
    /// <summary>
    /// Interaction logic for AKeyChanger.xaml
    /// </summary>
    public partial class AKeyChanger : UserControl
    {
        public AKeyChanger(string Text, string Keybind)
        {
            InitializeComponent();
            KeyChangerTitle.Content = Text;

            string displayName = KeybindNameManager.ConvertToRegularKey(Keybind);
            KeyNotifier.Content = $"[ {displayName} ]";
        }
    }
}